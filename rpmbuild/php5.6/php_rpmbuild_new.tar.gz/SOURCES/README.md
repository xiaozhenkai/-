`wget http://cn2.php.net/distributions/php-5.6.31.tar.gz`
